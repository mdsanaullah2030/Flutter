export class RegistrationModel {
    id!: number;
    name!: string;
    presentAddress !: String;
    permanentAddress!: String;
    gender!: String;
    age!: Number;
    cellNo!:String



}